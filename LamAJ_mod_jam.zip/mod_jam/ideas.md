## Mod Jam ideas: 

    1. Make the frog pink or purple (it could be cute, easily done within the fucntion drawFrog(), but it could be interesting to trigger the colour change instead??)

    2.  Change the fly into another insect (having just a fly is a bit boring, since frog don't only eat flies, but other insects as well, a variety of insects)

    3. Add a timer (make a timer count that should probably change somthing in the game?)

    4. Limit the amount of time allowed to eat or catch flies (it could be done? make a game over if time === 2mins or more?)

    5. Add a sound when you win or lose (might sound a bit basic, but with the right sound it could be funny. Will have to look up how to add audio to specific moments, or make an audio run during the game and change when you lose)

    6. Add a sound when you catch flies or other insects (the same principle as the previous idea, but make a slurp or catch sound when interacting with the fly, probably will use an if)

    7. Possibility of changing the frog into another amphibian(maybe a chameleon or a gecho, a simple change of the drawFrog() from frog to another thing. It would be interesting to change the frog into a different animal.)

    8. Making the frog move by itself if not using the mouse X (arbitrary movement could make it a bit more dificult to win points, Not sure how to do it, but it is an option)

    9. Make the frog move with the left and right arrow key (It would be similar to online games, liek Fireboy and Watergirl. Will use keyPress and keycode = 37(left) and 39(right))

    10. Use space bar rather than mousePress to shoot tongue (change the mousepress to keypress and keycode = 32(spacebar) )

    11. Have a background that changes whenever you reach a threshold of points(easy enough with constraint, like the one I used in my Art Jam with (if)s and (else if)s. Will have to pick colours later on)

    12. Make the point counter increase by .5 rather than 1 point for every catch(Looked over how to add a scoring during class with text(), but it would make scoring more dificult.)

    13. Have a special effect when you catch flies, at every interval of 5, there's a change of background or insect? (A extra bling to the project that could make it fun, should be easily done with constraints or soemthing similar to that? If not a background colour change, than an explotion or dramatic boom)

    14. Increasing the speed of the flies when reaching a certaintrehshold of points.(rather than usinig a const for the fly's speed, I'll have to use a let flySpeed that'll increase if score reaches 5, or 10, or 15, or 20, etc)

    15. Make you lose if you click off the project webpage (Touched on it with Emile during the Event's challenge, using visibilitychange(). It's something simple, might just fo it for the hell of it)

    16. Add poisoned flies that reduce points when caught. (Included in the scoring? a let evilFlyScoreAmount = -.5 or something of the like to reducing the points when caught.)

    17. Make the screen black out if you lose (somehting simple enough to make?? With an if(gameOver) or something similar it should make the canvas black out)

    18. Add a day and night cycle. (Included in the time cycle, if time = 30sec it changes the time to night or day)

    19. Make a (+1) appear on the tip of the tongue whenever you catch a fly (Not sure how to make that work, but I'll have to look that up, if not I'll ask for help? I should probably start with a text() before anything)

    20. The ending(game over) screen should write down the score and time it took(have a function for it to make it or if to make the text slide in through the left or the right. I'm not sure if it's too advanced for my skill level but I could ask for help?)

    




