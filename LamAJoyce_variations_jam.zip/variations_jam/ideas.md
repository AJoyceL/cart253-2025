# ideas

> 2D game with dialogues using arrays
    - VARIATION ONE: a running game where the player has to jump and hit a paddle(block) to unlock a following dialogue or make the character engage with the player.
    - VARIATION TWO: a pixel art of a character where the player has to interact with to engage in dialogue. Possibility of pressing space to continue to the next dialogue.
    - VARIATION THREE: mousepress on buttons to summon dialogue, or make the player moavable on mouseX and mouseY and overlap with button to summon dialogue.

> MAIN CODE:
    - Use arrays for dialogue/speech.
    - Use if and else if to trigger the right speech.
    -     

> VARIATION ONE :
    - Similar to frogfrogfrog, but on a platform > constraint to handle the player position on the platform. 
    - Use keyIsDown to move the player.
    - Paddle/block that trigger speech when overlpapped.
    - Player jumps and falls back > inbound and outbound from frogfrogfrog.

> VARIATION TWO
    - Static player.
    - KeyPressed to trigger speech.
    - Draw big character.

>VARIATION THREE
    - Player can move with mouseX and mouseY, but constrained to ground only.
    - Overlap rocks or buttons to trigger speech from character.
    - Seperate ground from sky.