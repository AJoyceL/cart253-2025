Project name: Art Jam
Author: Joyce Angelina Lam

p5 reference:
// While I haven't technically used vertex() before this project myself, I watched Philippe use it in a prior challenge(Introduction challenge) and tought of using it to draw my self-portrait. 
Here's the link to vertex() : https://p5js.org/reference/p5/vertex/

USES: 
I used vertex() in drawFace() and drawHair() 


// Used map() as per recommended when I asked for help with limiting the motion range of the pupil/
here's the link to map() : https://p5js.org/reference/p5/map/

USES:
I used map() in drawPupil()
